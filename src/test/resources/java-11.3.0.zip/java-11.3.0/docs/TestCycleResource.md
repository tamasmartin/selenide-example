
# TestCycleResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**links** | [**List&lt;Link&gt;**](Link.md) |  |  [optional]
**id** | **Long** |  |  [optional]
**name** | **String** |  |  [optional]
**order** | **Integer** |  |  [optional]
**pid** | **String** |  |  [optional]
**createdDate** | [**DateTime**](DateTime.md) |  |  [optional]
**lastModifiedDate** | [**DateTime**](DateTime.md) |  |  [optional]
**webUrl** | **String** |  |  [optional]
**description** | **String** |  |  [optional]
**targetReleaseId** | **Long** |  |  [optional]
**targetBuildId** | **Long** |  |  [optional]
**testCycles** | [**List&lt;TestCycleResource&gt;**](TestCycleResource.md) |  |  [optional]
**testSuites** | [**List&lt;TestSuiteWithCustomFieldResource&gt;**](TestSuiteWithCustomFieldResource.md) |  |  [optional]



