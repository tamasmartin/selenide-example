
# TestParameter

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  |  [optional]
**name** | **String** |  |  [optional]
**active** | **Boolean** |  |  [optional]
**deleted** | **Boolean** |  |  [optional]
**clientId** | **Long** |  |  [optional]
**projectId** | **Long** |  |  [optional]



