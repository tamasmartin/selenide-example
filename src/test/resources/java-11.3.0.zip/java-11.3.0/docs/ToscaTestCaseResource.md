
# ToscaTestCaseResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**toscaUniqueId** | **String** |  | 
**toscaNodePath** | **String** |  | 
**toscaUrl** | **String** |  |  [optional]
**parentId** | **Long** |  |  [optional]
**parentType** | **String** |  |  [optional]



