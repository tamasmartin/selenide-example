
# IntegrationConnection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** |  |  [optional]
**externalSystem** | **String** |  |  [optional]
**connectionName** | **String** |  |  [optional]
**serverUrl** | **String** |  |  [optional]
**webUrl** | **String** |  |  [optional]
**authenticationType** | **String** |  |  [optional]
**username** | **String** |  |  [optional]
**token** | **String** |  |  [optional]



