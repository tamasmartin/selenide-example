
# AuthSystemResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ldaps** | [**List&lt;LdapConfigDetailResponse&gt;**](LdapConfigDetailResponse.md) |  |  [optional]
**sso** | [**SSOSamlConfigDetailResponse**](SSOSamlConfigDetailResponse.md) |  |  [optional]
**tua** | [**TUAConfigDetailResponse**](TUAConfigDetailResponse.md) |  |  [optional]



