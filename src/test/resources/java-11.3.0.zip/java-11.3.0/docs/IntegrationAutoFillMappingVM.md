
# IntegrationAutoFillMappingVM

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**externalProjectId** | **String** |  |  [optional]
**externalTypeId** | **String** |  |  [optional]
**sendAttachmentToJira** | **String** |  |  [optional]
**configures** | [**List&lt;AutoFillConfigurationVM&gt;**](AutoFillConfigurationVM.md) |  |  [optional]



