
# TestCasePermission

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**create** | **Boolean** | Can create Test Case |  [optional]
**edit** | **Boolean** | Can edit Test Case |  [optional]
**delete** | **Boolean** | Can delete Test Case |  [optional]
**view** | **Boolean** | Can view Test Case |  [optional]
**editAssignment** | **Boolean** | Can assign Test Case |  [optional]
**export** | **Boolean** | Can export Test Case |  [optional]
**_import** | **Boolean** | Can import Test Case |  [optional]
**approve** | **Boolean** | Can approve Test Case |  [optional]



