
# AllowedValueInputResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_default** | **Boolean** |  |  [optional]
**value** | **Long** |  |  [optional]
**label** | **String** |  |  [optional]
**order** | **Integer** |  |  [optional]
**isDefault** | **Boolean** |  |  [optional]
**isActive** | **Boolean** |  |  [optional]
**color** | **String** |  |  [optional]



