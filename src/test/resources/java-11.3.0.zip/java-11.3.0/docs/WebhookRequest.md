
# WebhookRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**url** | **String** |  |  [optional]
**events** | **List&lt;String&gt;** |  |  [optional]
**secretKey** | **String** |  |  [optional]
**responseType** | **String** |  |  [optional]
**projectIds** | **List&lt;Long&gt;** |  |  [optional]



