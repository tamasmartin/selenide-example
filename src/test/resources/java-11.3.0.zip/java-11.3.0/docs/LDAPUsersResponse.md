
# LDAPUsersResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;LdapUserVM&gt;**](LdapUserVM.md) |  |  [optional]
**total** | **Integer** |  |  [optional]
**pageSize** | **Integer** |  |  [optional]
**page** | **Integer** |  |  [optional]



