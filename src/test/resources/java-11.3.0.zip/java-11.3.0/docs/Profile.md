
# Profile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | ID of Profile |  [optional]
**name** | **String** | Name of Profile |  [optional]
**isReadonly** | **Boolean** | Is readonly or not |  [optional]
**isAdmin** | **Boolean** | Is admin profile or not |  [optional]



