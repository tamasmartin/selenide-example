
# CustomFieldInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** |  |  [optional]
**value** | **String** |  |  [optional]
**objectId** | **Long** |  |  [optional]
**type** | **String** |  |  [optional]
**name** | **String** |  |  [optional]



