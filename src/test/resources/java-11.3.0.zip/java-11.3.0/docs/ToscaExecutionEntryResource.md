
# ToscaExecutionEntryResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**toscaUniqueId** | **String** |  | 
**name** | **String** |  | 
**toscaNodePath** | **String** |  | 
**toscaUrl** | **String** |  |  [optional]
**parentId** | **Long** |  |  [optional]
**parentType** | **String** |  |  [optional]
**associatedToscaTestCase** | [**ToscaTestCaseResource**](ToscaTestCaseResource.md) |  |  [optional]
**associatedToscaTestCaseId** | **String** |  |  [optional]



