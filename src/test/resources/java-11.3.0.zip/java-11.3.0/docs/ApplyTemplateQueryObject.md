
# ApplyTemplateQueryObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**projectIds** | **List&lt;Long&gt;** |  |  [optional]
**createNewSiteFieldValues** | **Boolean** |  |  [optional]



