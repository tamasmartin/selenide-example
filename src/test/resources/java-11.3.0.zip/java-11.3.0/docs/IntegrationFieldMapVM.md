
# IntegrationFieldMapVM

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**externalFieldId** | **String** |  |  [optional]
**externalFieldName** | **String** |  |  [optional]
**active** | **Boolean** |  |  [optional]



