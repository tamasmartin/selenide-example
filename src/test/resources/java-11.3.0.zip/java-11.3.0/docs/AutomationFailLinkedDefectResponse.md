
# AutomationFailLinkedDefectResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pids** | **List&lt;String&gt;** | Failed linked defects |  [optional]
**error** | **String** | Error message |  [optional]



