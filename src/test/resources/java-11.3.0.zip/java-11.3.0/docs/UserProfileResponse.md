
# UserProfileResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userProfiles** | [**List&lt;Profile&gt;**](Profile.md) | Arrays of User Profile |  [optional]
**adminProfiles** | [**List&lt;Profile&gt;**](Profile.md) | Arrays of Admin Profile |  [optional]
**totalUserProfiles** | **Integer** | Total User Profile |  [optional]
**totalAdminProfiles** | **Integer** | Total Admin Profile |  [optional]



