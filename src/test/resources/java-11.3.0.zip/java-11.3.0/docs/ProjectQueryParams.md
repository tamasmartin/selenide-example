
# ProjectQueryParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uuid** | **List&lt;String&gt;** | UUID of the Project |  [optional]



