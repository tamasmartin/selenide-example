
# IntegrationReleaseConfigurationVM

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**autoUpdate** | **Boolean** |  |  [optional]
**configurationValues** | [**IntegrationReleaseConfigurationValues**](IntegrationReleaseConfigurationValues.md) |  |  [optional]
**dataRetrievalOptions** | **List&lt;String&gt;** |  |  [optional]
**autoUpdateReleaseScope** | **String** |  |  [optional]



