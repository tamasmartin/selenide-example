
# UserInfoVM

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** |  |  [optional]
**userName** | **String** |  |  [optional]
**firstName** | **String** |  |  [optional]
**lastName** | **String** |  |  [optional]
**contactEmail** | **String** |  |  [optional]
**fullName** | **String** |  |  [optional]
**userDN** | **String** |  |  [optional]



