
# LinkedArtifactContainer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | ID of source artifact |  [optional]
**pid** | **String** | PID of source artifact&#x60; |  [optional]
**objects** | [**List&lt;LinkedArtifact&gt;**](LinkedArtifact.md) | Arrays of linked artifact |  [optional]



