
# TraceabilityRequirement

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**order** | **Long** | Order |  [optional]
**root** | **Boolean** | Is root Requirement Module or not |  [optional]
**children** | [**List&lt;TraceabilityRequirement&gt;**](TraceabilityRequirement.md) | Arrays of TraceabilityRequirement |  [optional]
**requirements** | [**List&lt;Map&lt;String, Object&gt;&gt;**](Map.md) | Arrays of Requirement data |  [optional]



