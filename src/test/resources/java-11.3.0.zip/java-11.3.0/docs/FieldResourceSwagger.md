
# FieldResourceSwagger

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instanceType** | **String** |  |  [optional]
**links** | [**List&lt;Link&gt;**](Link.md) |  |  [optional]
**id** | **Long** |  |  [optional]
**attributeType** | **String** |  |  [optional]
**label** | **String** |  | 
**required** | **Boolean** |  |  [optional]
**constrained** | **Boolean** |  |  [optional]
**order** | **Integer** |  |  [optional]
**multiple** | **Boolean** |  |  [optional]
**dataType** | **Long** |  |  [optional]
**searchable** | **Boolean** |  |  [optional]
**freeTextSearch** | **Boolean** |  |  [optional]
**defaultValue** | **String** |  |  [optional]
**systemField** | **Boolean** |  |  [optional]
**originalName** | **String** |  |  [optional]
**isActive** | **Boolean** |  |  [optional]



