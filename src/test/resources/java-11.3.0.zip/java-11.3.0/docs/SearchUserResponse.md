
# SearchUserResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**links** | [**List&lt;Link&gt;**](Link.md) | Link to resource |  [optional]
**page** | **Integer** | Current page number |  [optional]
**pageSize** | **Integer** | Current page size number |  [optional]
**total** | **Long** | Total user found |  [optional]
**items** | [**List&lt;SearchUserResource&gt;**](SearchUserResource.md) | Arrays of User |  [optional]
**totalProject** | **Long** | Total Project found |  [optional]



