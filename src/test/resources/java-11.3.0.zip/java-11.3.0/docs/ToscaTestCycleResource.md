
# ToscaTestCycleResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**toscaUniqueId** | **String** |  | 
**name** | **String** |  | 
**description** | **String** |  |  [optional]
**toscaObjectType** | **String** |  |  [optional]
**toscaNodePath** | **String** |  | 
**toscaUrl** | **String** |  |  [optional]
**parentId** | **Long** |  |  [optional]
**parentType** | **String** |  |  [optional]
**testCycles** | **List&lt;String&gt;** |  |  [optional]
**testRuns** | [**List&lt;ToscaExecutionEntryResource&gt;**](ToscaExecutionEntryResource.md) |  |  [optional]



