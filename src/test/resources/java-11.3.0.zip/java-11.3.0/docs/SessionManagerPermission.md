
# SessionManagerPermission

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**create** | **Boolean** | Can create Session |  [optional]
**edit** | **Boolean** | Can edit Session |  [optional]
**delete** | **Boolean** | Can delete Session |  [optional]
**view** | **Boolean** | Can view Session |  [optional]



