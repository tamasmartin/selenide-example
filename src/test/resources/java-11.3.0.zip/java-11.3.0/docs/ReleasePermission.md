
# ReleasePermission

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**create** | **Boolean** | Can create Release |  [optional]
**edit** | **Boolean** | Can edit Release |  [optional]
**delete** | **Boolean** | Can delete Release |  [optional]
**view** | **Boolean** | Can view Release |  [optional]



