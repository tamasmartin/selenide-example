
# ReportPermission

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**viewReport** | **Boolean** | Can view Report |  [optional]



