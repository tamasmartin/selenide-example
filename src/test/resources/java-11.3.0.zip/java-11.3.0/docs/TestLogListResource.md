
# TestLogListResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**links** | [**List&lt;Link&gt;**](Link.md) |  |  [optional]
**page** | **Integer** |  |  [optional]
**pageSize** | **Integer** |  |  [optional]
**total** | **Long** |  |  [optional]
**items** | [**List&lt;TestLogResource&gt;**](TestLogResource.md) |  |  [optional]



