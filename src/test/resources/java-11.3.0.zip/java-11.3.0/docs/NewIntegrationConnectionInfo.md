
# NewIntegrationConnectionInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**connectionId** | **Long** |  |  [optional]
**status** | **String** |  |  [optional]



