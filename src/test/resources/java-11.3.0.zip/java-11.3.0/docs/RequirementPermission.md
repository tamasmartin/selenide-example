
# RequirementPermission

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**create** | **Boolean** | Can create Requirement  |  [optional]
**edit** | **Boolean** | Can edit Requirement |  [optional]
**delete** | **Boolean** | Can delete Requirement |  [optional]
**view** | **Boolean** | Can view Requirement |  [optional]
**editAssignment** | **Boolean** | Can assign user to Requirement |  [optional]
**export** | **Boolean** | Can export Requirement |  [optional]
**_import** | **Boolean** | Can import Requirement |  [optional]



