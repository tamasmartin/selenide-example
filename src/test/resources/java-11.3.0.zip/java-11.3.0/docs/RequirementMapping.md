
# RequirementMapping

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**externalProjectId** | **String** |  |  [optional]
**externalTypeId** | **String** |  |  [optional]
**mappingId** | **Long** |  |  [optional]
**externalFilter** | **String** |  |  [optional]
**externalField1Id** | **String** |  |  [optional]
**externalField2Id** | **String** |  |  [optional]
**activeExternalFields** | **String** |  |  [optional]



