
# ParameterValueVM

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  |  [optional]
**value** | **String** |  |  [optional]



