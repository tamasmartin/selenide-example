
# PagedResourceAttachmentResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**links** | [**List&lt;Link&gt;**](Link.md) |  |  [optional]
**page** | **Integer** |  |  [optional]
**pageSize** | **Integer** |  |  [optional]
**total** | **Long** |  |  [optional]
**items** | [**List&lt;AttachmentResource&gt;**](AttachmentResource.md) |  |  [optional]



