
# StatusResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**links** | [**List&lt;Link&gt;**](Link.md) | Link to resource |  [optional]
**id** | **Long** | ID of Test Run&#39;s status |  [optional]
**name** | **String** | Name of Test Run&#39;s status |  [optional]
**isDefault** | **Boolean** | Is default or not |  [optional]
**color** | **String** | Color of Test Run&#39;s status |  [optional]
**active** | **Boolean** | Active or not |  [optional]



