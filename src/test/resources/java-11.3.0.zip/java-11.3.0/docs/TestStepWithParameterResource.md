
# TestStepWithParameterResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**stepId** | **Long** |  | 
**descriptionParameterValues** | **List&lt;String&gt;** |  |  [optional]
**expectedParameterValues** | **List&lt;String&gt;** |  |  [optional]



