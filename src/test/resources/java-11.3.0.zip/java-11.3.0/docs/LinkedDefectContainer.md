
# LinkedDefectContainer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | ID of source artifact |  [optional]
**objects** | [**List&lt;LinkedDefect&gt;**](LinkedDefect.md) | Arrays of linked defect |  [optional]



