
# AllowedValueResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**links** | [**List&lt;Link&gt;**](Link.md) |  |  [optional]
**value** | **Long** | Value of AllowedValue |  [optional]
**label** | **String** | Label of AllowedValue |  [optional]
**order** | **Integer** | Display order of AllowedValue |  [optional]
**isDefault** | **Boolean** | Is default value or not |  [optional]
**isActive** | **Boolean** | Is active or not |  [optional]
**color** | **String** | Color of AllowedValue if Field is Test Run&#39;s Status  |  [optional]



