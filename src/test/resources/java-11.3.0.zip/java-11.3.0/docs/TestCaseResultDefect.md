
# TestCaseResultDefect

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** |  |  [optional]
**clientId** | **Long** |  |  [optional]
**projectId** | **Long** |  |  [optional]
**resultId** | **Long** |  |  [optional]
**defectId** | **Long** |  |  [optional]
**externalIssueId** | **String** |  |  [optional]
**externalIssueUniqueId** | **String** |  |  [optional]
**externalIssueStatus** | **String** |  |  [optional]
**externalIssueResolution** | **String** |  |  [optional]
**externalIssueType** | **String** |  |  [optional]
**externalIssueSummary** | **String** |  |  [optional]
**externalIssueUrl** | **String** |  |  [optional]
**integrationConnectionId** | **Long** |  |  [optional]
**externalProjectId** | **String** |  |  [optional]
**resultType** | **Long** |  |  [optional]
**defect** | [**Defect**](Defect.md) |  |  [optional]
**testCaseId** | **Long** |  |  [optional]
**testCaseRunId** | **Long** |  |  [optional]
**testCaseVersionId** | **Long** |  |  [optional]
**deleted** | **Boolean** |  |  [optional]
**longId** | **Long** |  |  [optional]
**internalDefect** | **Boolean** |  |  [optional]



