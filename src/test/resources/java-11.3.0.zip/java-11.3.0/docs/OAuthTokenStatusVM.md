
# OAuthTokenStatusVM

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**expiration** | **Long** |  |  [optional]
**validityInMilliseconds** | **Long** |  |  [optional]



