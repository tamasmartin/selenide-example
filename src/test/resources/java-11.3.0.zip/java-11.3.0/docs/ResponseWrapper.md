
# ResponseWrapper

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | **Object** |  |  [optional]
**errors** | [**List&lt;ErrorMessage&gt;**](ErrorMessage.md) |  |  [optional]



