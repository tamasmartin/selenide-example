
# AutomationStepLog

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**testStepLogId** | **Long** |  | 
**actualResult** | **String** |  |  [optional]
**status** | **String** |  |  [optional]
**exeDate** | [**DateTime**](DateTime.md) | Execution date |  [optional]



