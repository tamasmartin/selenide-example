
# HistoryResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created** | [**DateTime**](DateTime.md) |  |  [optional]
**description** | **String** |  |  [optional]
**links** | [**List&lt;Link&gt;**](Link.md) |  |  [optional]
**id** | **Long** |  |  [optional]
**authorId** | **Long** |  |  [optional]
**linkedObject** | [**LinkedObject**](LinkedObject.md) |  |  [optional]
**changes** | [**List&lt;HistoryChange&gt;**](HistoryChange.md) |  |  [optional]



