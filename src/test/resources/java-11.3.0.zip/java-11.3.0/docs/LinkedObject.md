
# LinkedObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**objectType** | **String** |  |  [optional]
**objectId** | **Long** |  |  [optional]



