
# IntegrationConnectionVM

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** |  |  [optional]
**externalSystem** | **String** |  |  [optional]
**connectionName** | **String** |  |  [optional]
**serverUrl** | **String** |  |  [optional]
**webUrl** | **String** |  |  [optional]
**active** | **Boolean** |  |  [optional]



