
# ProjectSettingPermission

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**manage** | **Boolean** | Can manage project setting or not |  [optional]



