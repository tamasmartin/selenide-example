
# PropertyResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fieldId** | **Long** | ID of Field | 
**fieldName** | **String** | Name of Field |  [optional]
**fieldValue** | **String** | Value of Field |  [optional]
**fieldValueName** | **String** | Name Value of Field |  [optional]



