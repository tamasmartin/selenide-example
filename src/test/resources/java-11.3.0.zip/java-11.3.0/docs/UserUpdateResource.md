
# UserUpdateResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**links** | [**List&lt;Link&gt;**](Link.md) |  |  [optional]
**id** | **Long** |  |  [optional]
**email** | **String** |  |  [optional]
**password** | **String** |  |  [optional]
**firstName** | **String** |  |  [optional]
**lastName** | **String** |  |  [optional]
**status** | **Integer** |  |  [optional]
**userGroupIds** | **List&lt;Long&gt;** |  |  [optional]
**externalAuthConfigId** | **Long** |  |  [optional]
**externalUserName** | **String** |  |  [optional]



