
# AssignedUsersProject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**projectId** | **Long** | ID of the Project |  [optional]
**profile** | [**Profile**](Profile.md) |  |  [optional]
**userIds** | **List&lt;Long&gt;** | Array User ID |  [optional]



