
# TestRunWithParameterCreateByDatasetResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**properties** | [**List&lt;PropertyResource&gt;**](PropertyResource.md) |  |  [optional]
**testCase** | [**TestCaseWithParameterResource**](TestCaseWithParameterResource.md) |  | 
**datasetId** | **String** |  |  [optional]
**fromRow** | **Long** |  |  [optional]
**numberOfRows** | **Long** |  |  [optional]



