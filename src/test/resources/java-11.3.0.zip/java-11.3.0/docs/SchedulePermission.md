
# SchedulePermission

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**create** | **Boolean** | Can create schedule |  [optional]
**edit** | **Boolean** | Can edit schedule |  [optional]
**delete** | **Boolean** | Can delete schedule |  [optional]
**view** | **Boolean** | Can views&#x3D; schedule |  [optional]



