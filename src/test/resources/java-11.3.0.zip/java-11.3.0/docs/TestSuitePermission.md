
# TestSuitePermission

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**create** | **Boolean** | Can create Test Suite |  [optional]
**edit** | **Boolean** | Can edit Test Suite |  [optional]
**delete** | **Boolean** | Can delete Test Suite |  [optional]
**view** | **Boolean** | Can view Test Suite |  [optional]



