
# SiteUsersProfile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userProfileId** | **Long** | ID of user profile |  [optional]
**userIds** | **List&lt;Long&gt;** | Array User ID |  [optional]



