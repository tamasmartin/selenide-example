
# ProjectWithUserIdsObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**projectId** | **Long** | ID of the Project |  [optional]
**userIds** | **List&lt;Long&gt;** | Array User ID |  [optional]



