
# DefectPermission

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**create** | **Boolean** | Can create Defect |  [optional]
**edit** | **Boolean** | Can edit Defect |  [optional]
**delete** | **Boolean** |  |  [optional]
**view** | **Boolean** | Can view Defect |  [optional]
**export** | **Boolean** | Can export Defect |  [optional]



