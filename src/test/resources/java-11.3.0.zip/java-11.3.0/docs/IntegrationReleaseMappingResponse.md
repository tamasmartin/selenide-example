
# IntegrationReleaseMappingResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**externalProjectId** | **String** |  |  [optional]
**externalIssueTypeId** | **String** |  |  [optional]
**dataRetrievalOptions** | **List&lt;String&gt;** |  |  [optional]
**autoUpdateReleaseScope** | **String** |  |  [optional]



