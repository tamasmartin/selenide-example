
# DefectComment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** |  |  [optional]
**clientId** | **Long** |  |  [optional]
**projectId** | **Long** |  |  [optional]
**objectId** | **Long** |  |  [optional]
**objectTypeId** | **Long** |  |  [optional]
**userId** | **Long** |  |  [optional]
**objectComment** | **String** |  |  [optional]
**commentDate** | [**DateTime**](DateTime.md) |  |  [optional]
**editDate** | [**DateTime**](DateTime.md) |  |  [optional]
**defect** | [**Defect**](Defect.md) |  |  [optional]
**longId** | **Long** |  |  [optional]



