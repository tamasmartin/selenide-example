
# CustomFieldTemplate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** |  |  [optional]
**clientId** | **Long** |  |  [optional]
**name** | **String** |  |  [optional]
**_default** | **Boolean** |  |  [optional]



