
# TestRunWithParameterCreateManualResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**properties** | [**List&lt;PropertyResource&gt;**](PropertyResource.md) |  |  [optional]
**testCase** | [**TestCaseWithParameterResource**](TestCaseWithParameterResource.md) |  | 
**testRuns** | [**List&lt;List&lt;TestStepWithParameterResource&gt;&gt;**](List.md) |  | 



