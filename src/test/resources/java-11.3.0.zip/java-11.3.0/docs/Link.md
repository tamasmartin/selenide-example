
# Link

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rel** | **String** | Relationship of link to object |  [optional]
**href** | **String** | URL to the resource |  [optional]



