
# AllowedValueResponseResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**links** | [**List&lt;Link&gt;**](Link.md) |  |  [optional]
**total** | **Long** |  |  [optional]
**items** | [**List&lt;AllowedValueResource&gt;**](AllowedValueResource.md) |  |  [optional]



