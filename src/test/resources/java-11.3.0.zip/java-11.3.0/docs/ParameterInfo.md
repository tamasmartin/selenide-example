
# ParameterInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parameter** | [**ParameterVM**](ParameterVM.md) |  |  [optional]
**info** | [**TestParameter**](TestParameter.md) |  |  [optional]
**parameterValue** | [**ParameterValueVM**](ParameterValueVM.md) |  |  [optional]



