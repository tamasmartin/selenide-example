
# LinkedDefect

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | Defect id |  [optional]
**pid** | **String** | Defect pid |  [optional]
**linkType** | **String** | Link type |  [optional]
**externalDefectId** | **String** | External defect id |  [optional]
**connectionId** | **Long** | Defect connection id |  [optional]
**externalProjectId** | **String** | External project id |  [optional]
**summary** | **String** | Defect summary |  [optional]
**status** | **String** | Defect status |  [optional]



