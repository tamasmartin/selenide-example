
# TestStepInformationVM

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **String** |  |  [optional]
**descriptionInfo** | [**ParameterizationText**](ParameterizationText.md) |  |  [optional]
**expectedResult** | **String** |  |  [optional]
**actualResult** | **String** |  |  [optional]
**expectedResultInfo** | [**ParameterizationText**](ParameterizationText.md) |  |  [optional]
**customFieldInfo** | [**List&lt;CustomFieldInfo&gt;**](CustomFieldInfo.md) |  |  [optional]



