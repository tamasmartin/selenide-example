
# IntegrationReleaseConfigurationValues

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**unreleased** | **Boolean** |  |  [optional]
**released** | **Boolean** |  |  [optional]
**active** | **Boolean** |  |  [optional]
**future** | **Boolean** |  |  [optional]
**completed** | **Boolean** |  |  [optional]



