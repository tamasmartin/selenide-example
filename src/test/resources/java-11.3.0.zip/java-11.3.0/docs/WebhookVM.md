
# WebhookVM

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** |  |  [optional]
**name** | **String** |  |  [optional]
**url** | **String** |  |  [optional]
**events** | **List&lt;String&gt;** |  |  [optional]
**createdDate** | [**DateTime**](DateTime.md) |  |  [optional]
**lastModifiedDate** | [**DateTime**](DateTime.md) |  |  [optional]
**secretKey** | **String** |  |  [optional]
**responseType** | **String** |  |  [optional]
**projectIds** | **List&lt;Long&gt;** |  |  [optional]



