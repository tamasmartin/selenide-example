
# TestRunPermission

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**create** | **Boolean** | Can create Test Run |  [optional]
**edit** | **Boolean** | Can edit Test Run |  [optional]
**delete** | **Boolean** | Can delete Test Run |  [optional]
**view** | **Boolean** | Can view Test Run |  [optional]
**execute** | **Boolean** | Can execute Test Run |  [optional]
**export** | **Boolean** | Can export Test Run |  [optional]
**editAssignment** | **Boolean** | Can assign user to Test Run |  [optional]
**modifyTestLogsBySelf** | **Boolean** |  |  [optional]
**modifyTestLogsByOthers** | **Boolean** |  |  [optional]



