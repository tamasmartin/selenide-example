
# SearchUserResourceExtensionResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**links** | [**List&lt;Link&gt;**](Link.md) |  |  [optional]
**page** | **Integer** | Current page number |  [optional]
**pageSize** | **Integer** | Current page size number |  [optional]
**total** | **Long** | Total user found |  [optional]
**items** | [**List&lt;UserResourceExtension&gt;**](UserResourceExtension.md) | Arrays of User |  [optional]



