
# BuildPermission

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**create** | **Boolean** | Can create Build |  [optional]
**edit** | **Boolean** | Can edit Build |  [optional]
**delete** | **Boolean** | Can delete Build |  [optional]
**view** | **Boolean** | Can view Build |  [optional]



