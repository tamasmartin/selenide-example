
# AutoFillConfigurationVM

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**externalFieldId** | **String** |  |  [optional]
**qTestFieldIds** | **String** |  |  [optional]



