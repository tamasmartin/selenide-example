
# ExternalPropertyResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  |  [optional]
**link** | **String** |  |  [optional]
**uniqueId** | **String** |  |  [optional]



