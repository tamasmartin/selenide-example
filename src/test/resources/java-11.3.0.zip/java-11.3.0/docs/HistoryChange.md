
# HistoryChange

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**field** | **String** |  |  [optional]
**oldValue** | **String** |  |  [optional]
**newValue** | **String** |  |  [optional]



