
# AutomationArtifactSearchParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fields** | **List&lt;String&gt;** | fields: specify which object fields you want to include in the response. If you omit it or specify an asterisk (*), all fields are included |  [optional]
**query** | **String** | Represent text as Data Query |  [optional]



