
# ParameterTestStepResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**stepId** | **Long** |  |  [optional]
**descriptionParameterValues** | **List&lt;String&gt;** |  |  [optional]
**expectedParameterValues** | **List&lt;String&gt;** |  |  [optional]



