
# TestRunWithParameterCreateRandomResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**properties** | [**List&lt;PropertyResource&gt;**](PropertyResource.md) |  |  [optional]
**testCase** | [**TestCaseWithParameterResource**](TestCaseWithParameterResource.md) |  | 
**combinedType** | **Integer** |  | 
**numberOfCombinations** | **Integer** |  |  [optional]



