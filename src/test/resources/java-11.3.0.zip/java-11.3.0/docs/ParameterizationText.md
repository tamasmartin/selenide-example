
# ParameterizationText

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parameters** | [**List&lt;ParameterInfo&gt;**](ParameterInfo.md) |  |  [optional]
**rawText** | **String** |  |  [optional]
**editedParameters** | [**List&lt;ParameterInfo&gt;**](ParameterInfo.md) |  |  [optional]
**htmlText** | **String** |  |  [optional]
**plainValueText** | **String** |  |  [optional]
**valueText** | **String** |  |  [optional]
**plainText** | **String** |  |  [optional]



