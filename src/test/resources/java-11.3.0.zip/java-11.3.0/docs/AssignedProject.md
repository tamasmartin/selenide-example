
# AssignedProject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**projectId** | **Long** | ID of the Project |  [optional]
**profile** | [**Profile**](Profile.md) |  |  [optional]



