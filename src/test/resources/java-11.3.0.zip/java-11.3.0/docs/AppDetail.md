
# AppDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Manager |  [optional]
**logoUrl** | **String** | &lt;link to qTest application logo&gt; |  [optional]
**displayOrder** | **Integer** | Display order of qTest application |  [optional]
**url** | **String** | URL to qTest application |  [optional]
**redirectUrl** | **String** |  |  [optional]
**appType** | **String** |  |  [optional]



