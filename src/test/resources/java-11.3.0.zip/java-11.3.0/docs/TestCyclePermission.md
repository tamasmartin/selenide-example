
# TestCyclePermission

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**create** | **Boolean** | Can create Test Cycle |  [optional]
**edit** | **Boolean** | Can edit Test Cycle |  [optional]
**delete** | **Boolean** | Can edit Test Cycle |  [optional]
**view** | **Boolean** | Can view Test Cycle |  [optional]



