
# ShortTestLogResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **String** |  |  [optional]
**id** | **Long** |  |  [optional]
**exeStartDate** | [**DateTime**](DateTime.md) |  |  [optional]
**exeEndDate** | [**DateTime**](DateTime.md) |  |  [optional]



