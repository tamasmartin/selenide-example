
# AttachmentAuthor

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | ID of the User |  [optional]
**email** | **String** | Login username of the User |  [optional]
**firstName** | **String** | First name of the User |  [optional]
**lastName** | **String** | Last name of the User |  [optional]



