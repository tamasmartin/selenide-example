
# TokenSecretVerifierHolder

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jiraToken** | **String** |  |  [optional]
**jiraSecret** | **String** |  |  [optional]
**authorizeUrl** | **String** |  |  [optional]



