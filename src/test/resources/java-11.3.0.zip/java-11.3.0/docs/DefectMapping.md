
# DefectMapping

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**typeId** | **Long** |  |  [optional]
**type** | **String** |  |  [optional]
**typeLabel** | **String** |  |  [optional]
**projectId** | **Long** |  |  [optional]
**project** | **String** |  |  [optional]
**projectLabel** | **String** |  |  [optional]
**fields** | [**List&lt;DefectFieldMapping&gt;**](DefectFieldMapping.md) |  |  [optional]



