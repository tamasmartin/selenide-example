
# TestCaseWithParameterResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**testCaseVersionId** | **Long** |  |  [optional]
**id** | **Long** |  | 



