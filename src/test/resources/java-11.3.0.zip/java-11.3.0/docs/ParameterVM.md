
# ParameterVM

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parameterId** | **Long** |  |  [optional]
**id** | **String** |  |  [optional]
**startIndex** | **Integer** |  |  [optional]
**endIndex** | **Integer** |  |  [optional]
**startWithoutPrefixIndex** | **Integer** |  |  [optional]
**endWithoutSuffixIndex** | **Integer** |  |  [optional]
**parameterName** | **String** |  |  [optional]



