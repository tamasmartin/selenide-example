
# QueueProcessingResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | ID of task after batch submit automation test logs |  [optional]
**state** | **String** | State of task after batch submit automation test logs |  [optional]
**contentType** | **String** | Content type of task after batch submit automation test logs |  [optional]
**content** | **String** | Data of task after batch submit automation test logs |  [optional]
**type** | **String** | Type of task after batch submit automation test logs |  [optional]



