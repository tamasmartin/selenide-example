
# Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**noLogging** | **Boolean** |  |  [optional]
**message** | **String** | Error message text |  [optional]



