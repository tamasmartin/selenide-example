
# LookUp

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** |  |  [optional]
**lookupValue** | **String** |  |  [optional]
**lookupTypeId** | **Long** |  |  [optional]
**clientId** | **Long** |  |  [optional]
**projectId** | **Long** |  |  [optional]
**systemValue** | **Boolean** |  |  [optional]
**order** | **Integer** |  |  [optional]



