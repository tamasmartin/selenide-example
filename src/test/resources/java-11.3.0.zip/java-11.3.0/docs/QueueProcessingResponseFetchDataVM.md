
# QueueProcessingResponseFetchDataVM

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** |  |  [optional]
**type** | **String** |  |  [optional]
**state** | **String** |  |  [optional]
**contentType** | **String** |  |  [optional]
**content** | **String** |  |  [optional]



