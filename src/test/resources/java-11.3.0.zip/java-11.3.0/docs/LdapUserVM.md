
# LdapUserVM

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uid** | **String** |  |  [optional]
**firstName** | **String** |  |  [optional]
**lastName** | **String** |  |  [optional]
**mail** | **String** |  |  [optional]
**activationLink** | **String** |  |  [optional]
**mappedUserId** | **Long** |  |  [optional]
**newMappedUserName** | **String** |  |  [optional]
**disabled** | **Boolean** |  |  [optional]
**userDN** | **String** |  |  [optional]
**externalUserId** | **String** |  |  [optional]



