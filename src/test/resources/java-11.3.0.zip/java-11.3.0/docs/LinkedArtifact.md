
# LinkedArtifact

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | ID of linked artifact |  [optional]
**pid** | **String** | PID of linked artifact |  [optional]
**linkType** | **String** | Type of relationship between source and linked Artifact  |  [optional]
**self** | **String** | URL to linked artifact |  [optional]



