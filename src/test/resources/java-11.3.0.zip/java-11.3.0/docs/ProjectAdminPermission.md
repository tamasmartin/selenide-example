
# ProjectAdminPermission

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**admin** | **Boolean** | Is project admin or not |  [optional]



