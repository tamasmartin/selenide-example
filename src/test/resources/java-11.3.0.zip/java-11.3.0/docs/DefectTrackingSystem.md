
# DefectTrackingSystem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**defectMappings** | [**List&lt;DefectMapping&gt;**](DefectMapping.md) |  |  [optional]
**connectionName** | **String** | Name of Integration Connection |  [optional]
**url** | **String** | URL to Integration Connection |  [optional]
**systemName** | **String** | System name of Integration Connection |  [optional]
**active** | **Boolean** | Status of Integration Connection |  [optional]
**id** | **Long** | ID of Integration Connection |  [optional]



