
# LdapUserResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ldapUsername** | **String** |  |  [optional]
**firstName** | **String** |  |  [optional]
**lastName** | **String** |  |  [optional]
**email** | **String** |  |  [optional]



