
# DefectFieldMapping

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**field** | **String** | External tracker Defect&#39;s field |  [optional]
**qtestFields** | **List&lt;String&gt;** | qTest Defect&#39;s field |  [optional]



