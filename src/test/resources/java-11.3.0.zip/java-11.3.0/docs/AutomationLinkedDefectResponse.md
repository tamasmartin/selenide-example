
# AutomationLinkedDefectResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**success** | **List&lt;String&gt;** | Successfully linked defects |  [optional]
**fail** | [**List&lt;AutomationFailLinkedDefectResponse&gt;**](AutomationFailLinkedDefectResponse.md) | Failed linked defects with reasons |  [optional]



