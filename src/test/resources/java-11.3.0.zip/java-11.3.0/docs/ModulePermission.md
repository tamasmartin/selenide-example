
# ModulePermission

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**create** | **Boolean** | Can create Module |  [optional]
**edit** | **Boolean** | Can edit Module |  [optional]
**delete** | **Boolean** | Can delete Module |  [optional]
**view** | **Boolean** | Can view Module |  [optional]



