
# PagedResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**links** | [**List&lt;Link&gt;**](Link.md) |  |  [optional]
**page** | **Integer** | Current page |  [optional]
**pageSize** | **Integer** | Current page size |  [optional]
**total** | **Long** | Total record found |  [optional]
**items** | [**List&lt;ResourceSupport&gt;**](ResourceSupport.md) | Data of records |  [optional]



